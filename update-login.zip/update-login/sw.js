/* SEN-FleetCare service worker — cache app shell saja.
   Request ke Supabase / API / domain lain TIDAK disentuh (langsung ke network). */
const CACHE = 'sen-fleetcare-v4';
const SHELL = [
  '/', '/index.html', '/manifest.json', '/login-photo.jpg', '/login-photo-portrait.jpg', '/login-brand.png',
  '/icon-192.png', '/icon-512.png', '/icon-maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // Supabase, Google Fonts, dll: biarkan

  // Halaman utama: network-first supaya update deploy langsung terbaca, fallback ke cache saat offline
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put('/index.html', copy)); return res; })
        .catch(() => caches.match('/index.html'))
    );
    return;
  }

  // Aset statis (icon, gambar): cache-first + refresh di belakang
  e.respondWith(
    caches.match(req).then((hit) => {
      const net = fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
